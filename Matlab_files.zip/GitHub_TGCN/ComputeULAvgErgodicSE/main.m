%This Matlab script is the main of the article:
%
% Andrea Pizzo, Daniel Verenzuela, Luca Sanguinetti and Emil Björnson, "Network Deployment for Maximal Energy Efficiency 
% in Uplink with Multislope Path Loss," IEEE Transactions on Green Communications and Networking, Submitted to.
%
%This is version 1.0 (Last edited: 10-April-2018)
%
%License: This code is licensed under the GPLv2 license. If you in any way
%use this code for research that results in publications, please cite our
%original article listed above.
%
%
%This script compute the lower bound on the average ergodic spectral
%efficiency as in Theorem 2 (Section 3) of the article cited above. 
%This is achieved by calling 3 functions: 
%functionExampleSetup, functionChannelEstimates and functionComputeSE_UL. The function "functionExampleSetup" 
%deploys the UEs and the BSs randomly wihin the coverage area as described
%in Section 2. The function "functionChannelEstimates" computes all the
%uplink channel estimate for all UEs in the entire network. The function
%"functionComputeSE_UL" uses the true channel and the channel estimates to
%compute the uplink average ergodic spectral efficiency.


%Empty workspace and close figures
close all;
clear;
clc;

%Number of UEs per BS
K = 10;

%Define the range of BS antennas
Mrange = 100;

%Extract maximum number of BS antennas
Mmax = max(Mrange);

%Define the average pilot reuse factor
fRange = 1:1:1; 

%Select the number of setups with random UE locations
nbrOfSetups = 1;

%Select the number of channel realizations per setup
nbrOfRealizations = 1;

% Generates BS locations over (1) a fixed grid or
% (2) as a Homogeneous Poisson Point Process H-PPP
deployment = 2;

% Generates the large scale path-loss coefficient using (1) single slope or
% (2) multi slope model
pathloss = 2;

% (1) Correlated or (2) Uncorellated channel fading
c = 2;

% Density of BSs for the random deployment
lambdaRange = fliplr([1 2:2:2]);

%Load fixed Propagation parameters
SetPropagationParameters;
%%

%Prepare to save simulation results
sumSE_MR = zeros(length(lambdaRange),length(fRange),length(Mrange),nbrOfSetups);
sumSE_ZF = zeros(length(lambdaRange),length(fRange),length(Mrange),nbrOfSetups);
sumSE_RZF = zeros(length(lambdaRange),length(fRange),length(Mrange),nbrOfSetups);
sumSE_SMMSE = zeros(length(lambdaRange),length(fRange),length(Mrange),nbrOfSetups);
sumSE_MMMSE = zeros(length(lambdaRange),length(fRange),length(Mrange),nbrOfSetups);


%% Go through all lambda values
for ll = 1:length(lambdaRange)
    
    %Output simulation progress
    disp([num2str(ll) ' lambda values out of ' num2str(length(lambdaRange))]);
    
    % Go through all setups
    for n = 1:nbrOfSetups
        
        %Output simulation progress
        disp([num2str(n) ' setups out of ' num2str(nbrOfSetups)]);
        
        if deployment  == 1
            
            L = 16;
            
        elseif deployment == 2
            
            %Generate the number of BSs in the area per km^2
            L = round(poissrnd(lambdaRange(ll)*(squareLength/1000)^2));
            
            %If the number is zero, then make a new realization
            while L == 0
                L = round(poissrnd(lambdaRange(ll)*(squareLength/1000)^2));
            end
    
        end
        
        %Compute channel statistics for one setup
        [R,channelGaindB] = functionExampleSetup(L,K,Mmax,accuracy,ASDdeg,squareLength,Pathloss_model,deployment,pathloss);
        
        %Compute the normalized average channel gain, where the normalization
        %is based on the noise power
        channelGainOverNoiseOriginal = channelGaindB - noiseVariancedBm;
        
        %Extract the average channel gains before power control
        channelGainOverNoise = channelGainOverNoiseOriginal;
        
        %Go through all cells
        for j = 1:L
            
            %Scale the average channel gains by applying the inverse statistical power control
            backoff = channelGainOverNoiseOriginal(:,j,j) + 10*log10(p) - DeltadB;
            channelGainOverNoise(:,j,:) = channelGainOverNoiseOriginal(:,j,:) - repmat(backoff,[1 1 L]);
            
        end
                
        %Go through all number of antennas
        for m = 1:length(Mrange)
            
            %Output simulation progress
%             disp([num2str(m) ' antennas out of ' num2str(length(Mrange))]);
            
            %Go through all pilot reuse factors
            for s = 1:length(fRange)
                
                %Extract pilot reuse factor
                f = fRange(s);
                
                if c == 1 %Correlated fading
                    
                    %Generate channel realizations with estimates and estimation
                    %error correlation matrices
                    [Hhat,C,tau_p,Rscaled] = functionChannelEstimates(R(1:Mrange(m),1:Mrange(m),:,:,:),channelGainOverNoiseOriginal,nbrOfRealizations,Mrange(m),K,L,p,f,deployment);
                    
                elseif c == 2 %Uncorrelated fading
                    
                    %Generate uncorrelated correlation matrices
                    Runcorr = repmat(eye(Mrange(m)),[1 1 K L L]);
                    
                    %Generate channel realizations with estimates and estimation
                    %error correlation matrices
                    [Hhat,C,tau_p,Rscaled] = functionChannelEstimates(Runcorr,channelGainOverNoise,DeltadB_pilot,nbrOfRealizations,Mrange(m),K,L,p,f,deployment);
                    
                end

                %Compute SEs using Theorem 4.1
                [SE_MR,SE_RZF,SE_MMMSE,SE_ZF,SE_SMMSE] = functionComputeSE_UL(Hhat,C,Rscaled,tau_c,tau_p,nbrOfRealizations,Mrange(m),K,L,p);

                %Save average sum SE per cell
                sumSE_MR(ll,s,m,n) = mean(sum(SE_MR,1));
                sumSE_ZF(ll,s,m,n) = mean(sum(SE_ZF,1));
                sumSE_SMMSE(ll,s,m,n) = mean(sum(SE_SMMSE,1));
                sumSE_RZF(ll,s,m,n) = mean(sum(SE_RZF,1));
                sumSE_MMMSE(ll,s,m,n) = mean(sum(SE_MMMSE,1));
                
                %Delete large matrices
                clear Hhat C Rscaled;
                
            end
            
        end
        
        %Delete large matrices
        clear R;
        
    end
    
        save('../SimulationResults/insertfilename','deployment','pathloss','c','DeltadB','DeltadB_pilot','Pathloss_model','lambdaRange','fRange','Mrange','K','sumSE_MR','sumSE_ZF','sumSE_RZF','sumSE_SMMSE','sumSE_MMMSE');

end

% %% Plot the simulation results
% mm = length(Mrange);
% 
% %Plot aggregate SE per cell vs BS density
% for ff = 1:length(fRange)
%     
%     figure(length(lambdaRange)+ff);
%     hold on; box on;
%     plot(lambdaRange,squeeze(mean(sumSE_MMMSE(:,ff,mm,:),4)),'rd-','LineWidth',1);
%     plot(lambdaRange,squeeze(mean(sumSE_SMMSE(:,ff,mm,:),4)),'b:','LineWidth',1);
%     plot(lambdaRange,squeeze(mean(sumSE_RZF(:,ff,mm,:),4)),'k-.','LineWidth',1);
%     plot(lambdaRange,squeeze(mean(sumSE_ZF(:,ff,mm,:),4)),'mo-','LineWidth',1);
%     plot(lambdaRange,squeeze(mean(sumSE_MR(:,ff,mm,:),4)),'bs-','LineWidth',1);
%         
% end
% 
